function montrer(id){
    document.getElementById(id).style.display='block';
}
function cacher(id){
    document.getElementById(id).style.display='none';
}
function envoyerLister(){
    document.getElementById('formLister').submit();
}

function validerNum(elem){
    var numf=document.getElementById(elem).value;
    var numRegExp=new RegExp("^[0-9]{1,4}$");
    if(numf!="" && numRegExp.test(numF))
        return true;
    return false;
}

function valider(){
    var numf=document.getElementById("numf").value;
    var titref=document.getElementById("titref").value;
    var dureef=document.getElementById("dureef").value;
    var realisf=document.getElementById("realisf").value;
    //var pochette=document.getElementById("pochette").value;
    var numRegExp=new RegExp("^[0-9]{1,4}$");
    if(numf!="" && titref!="" && dureef!="" && realisf!="")
        if(numRegExp.test(numf))
            return true;
    return false;
}